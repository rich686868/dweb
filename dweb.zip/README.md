## Heartstealer DOS & DDOS Script

# Installing:
   ```
   git clone https://github.com/KenDzz/heartstealer-Dos-Script.git
   ```
   ```
   cd heartstealer-Dos-Script/
   ```
   ```
   pip install -r requirements.txt
   ```
   ```
   perl heartstealer.pl
   ```
   
# Video:
https://user-images.githubusercontent.com/23150179/150908895-f40038af-1b62-4379-a721-6f8283fec2ef.mp4

